//connect to mongoose
const mongoose = require("mongoose");

//create Schema for ToDo
const ToDoSchema = new mongoose.Schema({
  email: String,
  title: String,
  progress: Number,
});

//Export Schema
const ToDoModel = mongoose.model("todos", ToDoSchema);
module.exports = ToDoModel;
