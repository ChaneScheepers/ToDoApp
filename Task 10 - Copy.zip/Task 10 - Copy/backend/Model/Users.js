//connect to mongoose
const mongoose = require("mongoose");
const { isEmail } = require("validator");
const bcrypt = require("bcrypt");


const isGmail = (e)=> e.endsWith("@gmail.com");

//create Schema for ToDo
const UserSchema = new mongoose.Schema({
  email: {
    type: String,
    required: [true, "Please enter an email"],
    unique: true, //Ensure only 1 type, cannot create custom message
    lowercase: true, //saves final password in lowercase
    validate:[
      { validator: isEmail, msg: 'please enter a valid email' },
      { validator: isGmail, msg: 'only gmail addresses allowed' }
  ],
  },
  password: {
    type: String,
    required: [true, "Please enter an password"],
    minlength: [6, "min password length is 6 characters"],
  },
});

//fire a function before a doc is saved to db
UserSchema.pre("save", async function (next) {
  const salt = await bcrypt.genSalt();
  this.password = await bcrypt.hash(this.password, salt);
  //   console.log("user about to be created & saved", this);
  next();
});

//static method to log in user
UserSchema.statics.login = async function (email, password) {
  const user = await this.findOne({ email });
  if (user) {
    const auth = await bcrypt.compare(password, user.password);
    if (auth) {
      return user;
    }
    throw Error("incorrect password");
  }
  throw Error("incorrect email");
};

//Export Schema
const UserModel = mongoose.model("users", UserSchema);

module.exports = UserModel;
