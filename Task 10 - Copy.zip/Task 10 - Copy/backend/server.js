const express = require("express");
const PORT = 8000;
const mongoose = require("mongoose");
const morgan = require("morgan");
const cors = require("cors");
const ToDoModel = require("./Model/ToDoModel");
const User = require("./Model/Users");
const app = express();
const jwt = require("jsonwebtoken");

//connect to DB
mongoose.connect(
  "mongodb+srv://chanescheep:Chane1104@cluster0.00szxty.mongodb.net/"
);
app.use(morgan("tiny"));
app.use(cors());
app.use(express.json());

///////Users//////////////////////////////////
//handle errors function
const handleErrors = (err) => {
  console.log(err.message, err.code);
  //The below will be replaced based on error and will be used to give feedback to user.
  let errors = { message: err.message };

  //incorrect email
  if (err.message === "incorrect email") {
    errors.email =
      "that email is not registered, please use an @gmail password.";
  }

  //incorrect email
  if (err.message === "incorrect password") {
    errors.password = "that password is incorrect";
  }

  // duplication error
  if (err.code === 11000) {
    errors.email = "email already exists";
    return errors;
  }

  //validate errors
  if (err.message.includes("user validation failed")) {
    Object.values(err.errors).forEach(({ properties }) => {
      errors[properties.path] = properties.message;
    });
  }

  return errors;
};

//create token function
const createToken = (id) => {
  return jwt.sign({ id }, "test1234");
};

///signup
app.post("/register", async (req, res) => {
  const { email, password } = req.body;

  //async
  try {
    const user = await User.create({ email, password });
    const token = createToken(user._id);
    res.cookie("jwt", token);
    res.status(201).json({ user: user._id });
  } catch (err) {
    //errors where created in models & errors is changed based on the below.
    const errors = handleErrors(err);
    res.status(400).send(errors);
  }
});

//login
//////////////////////////////////////////////////////////////compare password.
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.login(email, password);
    const token = createToken(user._id);
    res.cookie("jwt", token);
    res.status(200).json({ user: user._id });
  } catch (err) {
    const errors = handleErrors(err);
    res.status(400).send(errors);
  }
});

//////////////////////////////toDo/////////////////////////
//get To dos
app.get("/todos", (req, res) => {
  //const user = req.params.useremail (add:users to link above)
  ToDoModel.find({})
    //need to display todos based on email logged in (find by username)
    .then((todos) => res.json(todos))
    .catch((err) => res.json(err));
});

//Post - add new To dos
app.post("/todos", (req, res) => {
  let { title } = req.body;
  if (title.length > 140){
    res.status(400).send('The title cannot exceed 140 characters')
  }
  ToDoModel.create(req.body)
    .then((todos) => res.json(todos))
    .catch((err) => res.json(err));
});

//Put - change spesific by ID
app.put("/todos/:id", (req, res) => {
  const id = req.params.id;
  ToDoModel.findByIdAndUpdate(
    { _id: id },
    {
      email: req.body.email,
      title: req.body.title,
      progress: req.body.progress,
    }
  )
    .then((todos) => res.json(todos))
    .catch((err) => res.json(err));
});

app.delete("/todos/:id", (req, res) => {
  const id = req.params.id;
  ToDoModel.findByIdAndDelete({ _id: id })
    .then((todos) => res.json(todos))
    .catch((err) => res.json(err));
});

app.listen(PORT, (req, res) => {
  console.log(`Running on port: ${PORT}`);
});
