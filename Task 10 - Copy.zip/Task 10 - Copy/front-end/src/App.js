import { useEffect, useState } from "react";
import ListHeader from "./components/ListHeader";
import ListItem from "./components/ListItem";
import Auth from "./components/Auth";
import { useCookies } from "react-cookie";

function App() {
  const [cookies, setCookie, removeCookie] = useCookies(null);
  const authToken = cookies.AuthToken;
  const [tasks, setTasks] = useState();

  //fetch to do
  const getData = async () => {
    try {
      const responce = await fetch("http://localhost:8000/todos");
      //remember to add prop for user email
      const json = await responce.json();
      setTasks(json);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    if (authToken) {
      getData();
    }
  }, []);

  return (
    <div className="App">
      {!authToken && <Auth />}
      {authToken && (
        <>
          {
            <ListHeader
              listName={"Get your stuff done! 🐱"}
              getData={getData}
            />
          }
          {tasks?.map((task) => (
            <ListItem key={task._id} task={task} getData={getData} />
          ))}
        </>
      )}
    </div>
  );
}

export default App;
