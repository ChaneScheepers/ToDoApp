import { useState } from "react";
import axios from "axios";
import { useCookies } from "react-cookie";

function Auth() {
  const [cookies, setCookie, removeCookie] = useCookies(null);
  const [isLogIn, setIsLogin] = useState(true);
  const [error, setError] = useState(null);
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);
  const [confirmPassword, setConfirmPassword] = useState(null);

  const viewLogin = (status) => {
    setError(null);
    setIsLogin(status);
  };
  ///////////////////////////////////////////////////////////////////////////
  const handleSubmit = (e) => {
    e.preventDefault();
    //if it does not match does not do anything.
    if (password !== confirmPassword) {
    alert("Make sure your passwords match!");
    console.log(error);
    return;
    }
    const responce = axios
      .post("http://localhost:8000/register", { email, password })
      .then((data) => {
        setCookie("Email", email);
        setCookie("AuthToken", data.data.token);
        window.location.reload();
      })
      .catch((err) => setError(err.response));
  };
  ////////////////////////////////////////////////////////////////////
  const handleLogin = (e) => {
    e.preventDefault();
    const responce = axios
      .post("http://localhost:8000/login", { email, password })
      .then((data) => {
        setCookie("Email", email);
        setCookie("AuthToken", data.data.token);
        window.location.reload();
      })
      .catch((err) => setError(err.response));
  };

  //////////////////////////////////////////////////////////////////
  return (
    <div className="auth-container">
      <div className="auth-container-box">
        <form>
          <h2>{isLogIn ? "Please log in" : "Please sign up"}</h2>
          <input
            type="email"
            placeholder="email"
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="password"
            onChange={(e) => setPassword(e.target.value)}
          />
          {!isLogIn && (
            <input
              type="password"
              placeholder="confirm password"
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          )}
          {!isLogIn && (
            <input
              type="submit"
              className="create"
              onClick={(e) => {
                handleSubmit(e);
              }}
            />
          )}
          {isLogIn && (
            <input
              type="submit"
              className="create"
              onClick={(e) => {
                handleLogin(e);
              }}
            />
          )}
        </form>
        <div className="auth-options">
          {error && <p>{error.data.message}</p>}
          <button
            onClick={() => viewLogin(false)}
            style={{ backgroundColor: !isLogIn ? "gray" : "white" }}
          >
            Sign up
          </button>
          <button
            onClick={() => viewLogin(true)}
            style={{ backgroundColor: !isLogIn ? "white" : "gray" }}
          >
            Login
          </button>
        </div>
      </div>
    </div>
  );
}

export default Auth;
