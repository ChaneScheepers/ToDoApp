import { useState } from "react";
import axios from "axios";
import { useCookies } from "react-cookie";

function Modal({ mode, setShowModal, task, getData }) {
  const [cookies, setCookie, removeCookie] = useCookies(null);

  const editMode = mode === "edit" ? true : false;

  const [data, setData] = useState({
    email: editMode ? task.email : cookies.Email,
    title: editMode ? task.title : null,
    progress: editMode ? task.progress : null,
  });

  const EditToDo = (e) => {
    e.preventDefault();
    console.log(e.target);

    axios
      .put("http://localhost:8000/todos/" + task._id, {
        ...data,
      })
      .then((result) => {
        setShowModal(false);
        getData();
      })
      .catch((err) => console.log(err));
  };

  const Submit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:8000/todos", {
        ...data,
      })
      .then((result) => {
        console.log(result);
        setShowModal(false);
        getData();
      })
      .catch((err) => console.log(err));
  };

  const handleChange = (e) => {
    console.log("changing", e);
    const { name, value } = e.target;
    console.log(name, value);

    setData((data) => ({
      ...data,
      [name]: value,
    }));
  };

  return (
    <div className="overlay">
      <div className="modal">
        <div className="form-title-container">
          <h3>Create {mode} your task</h3>
          <button onClick={() => setShowModal(false)}>X</button>
        </div>

        <form>
          <input
            required
            maxLength={140}
            placeholder="Your task tile"
            name="title"
            value={data.title}
            onChange={handleChange}
          />
          <br />
          <label for="range">Drag to select your current progress</label>
          <input
            required
            type="range"
            id="range"
            min="0"
            max="100"
            name="progress"
            value={data.progress}
            onChange={handleChange}
          />
          <input
            className={mode}
            type="submit"
            onClick={editMode ? EditToDo : Submit}
          />
        </form>
      </div>
    </div>
  );
}

export default Modal;
