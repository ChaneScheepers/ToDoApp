function ProgressBar({ progress }) {
  //array of random colors for progressbar
  const colors = [
    "rgb (255, 214, 161)",
    "rgb(255, 175, 163)",
    "rgb(108, 115, 148)",
    "rgb(141, 181, 145)",
  ];

  const randomC = colors[Math.floor(Math.random() * colors.length)];
  return (
    <div className="outer-bar">
      <div
        className="inner-bar"
        style={{ width: `${progress}%`, backgroundColor: randomC }}
      ></div>
    </div>
  );
}

export default ProgressBar;
